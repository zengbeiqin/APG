from django.apps import AppConfig


class ApgConfig(AppConfig):
    name = 'APG'
